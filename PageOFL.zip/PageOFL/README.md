# PageOFL
Requirements:
- Python 3.8
- Pytorch 2.0.1
- Torchvision 0.15.2
- CUDA 10.1
Process:
- After configuring the parameters and setting the file save path, first run the fl_proto.py, and then run the dayafree_proto.py.
Acknowledgements:
- The code is based on the following work, thanks for the code: https://github.com/rong-dai/Co-Boosting
